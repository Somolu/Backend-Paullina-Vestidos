___
### Documentação no Swagger

http://{{url-aplicacao}}/modelo-backend-api/swagger-ui.html

___
