/**
 * Pacote para compartilhar artefatos para consumir APIs do Portal
 */
package br.ueg.modelo.api;