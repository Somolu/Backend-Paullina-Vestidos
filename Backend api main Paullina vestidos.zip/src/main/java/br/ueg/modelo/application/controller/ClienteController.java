package br.ueg.modelo.application.controller;

import br.ueg.modelo.api.util.Validation;
import br.ueg.modelo.application.dto.ClienteDTO;
import br.ueg.modelo.application.dto.FiltroClienteDTO;
import br.ueg.modelo.application.dto.FiltroTipoAmigoDTO;
import br.ueg.modelo.application.dto.TipoAmigoDTO;
import br.ueg.modelo.application.mapper.ClienteMapper;
import br.ueg.modelo.application.model.Cliente;
import br.ueg.modelo.application.model.Grupo;
import br.ueg.modelo.application.model.TipoAmigo;
import br.ueg.modelo.application.service.ClienteService;
import br.ueg.modelo.application.service.GenericCrudService;
import br.ueg.modelo.comum.exception.MessageResponse;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Api(tags = "Cliente API")
@RestController
@RequestMapping(path = "${app.api.base}/cliente")
public class ClienteController extends AbstractController {
    //public class TipoAmigoService extends GenericCrudService<TipoAmigo, Long> {
    @Autowired
    private ClienteMapper clienteMapper;

    @Autowired
    private ClienteService clienteService;

    @PreAuthorize("hasRole('ROLE_CLIENTE_INCLUIR')")
    @PostMapping
    @ApiOperation(value = "Inclusão/alteração de cliente.",
            notes = "Incluir/Alterar cliente.")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Success", response = ClienteDTO.class),
            @ApiResponse(code = 400, message = "Bad Request", response = MessageResponse.class),
            @ApiResponse(code = 404, message = "Not Found", response = MessageResponse.class)
    })
    public ResponseEntity<?> incluir(@ApiParam(value = "Informações de Cliente", required = true) @Valid @RequestBody ClienteDTO clienteDTO) {
        Cliente grupo = clienteMapper.toEntity(clienteDTO);
        return ResponseEntity.ok(clienteMapper.toDTO(clienteService.salvar(grupo)));
    }

    /**
     * Altera a instância de {@link ClienteDTO} na base de dados.
     *
     * @param id
     * @param clienteDTO
     * @return
     */
    @PreAuthorize("hasRole('ROLE_CLIENTE_ALTERAR')")
    @ApiOperation(value = "Altera as informações do cliente.", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiResponses({
            @ApiResponse(code = 200, message = "Success", response = ClienteDTO.class),
            @ApiResponse(code = 400, message = "Bad Request", response = MessageResponse.class)
    })
    @PutMapping(path = "/{id:[\\d]+}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> alterar(
            @ApiParam(value = "Código do Cliente", required = true) @PathVariable final BigDecimal id,
            @ApiParam(value = "Informações do Cliente", required = true) @Valid @RequestBody ClienteDTO clienteDTO) {
        Validation.max("id", id, 99999999L);
        Cliente cliente = clienteMapper.toEntity(clienteDTO);
        cliente.setId(id.longValue());
        Cliente clienteSaved = clienteService.salvar(cliente);
        return ResponseEntity.ok(clienteMapper.toDTO(clienteSaved));
    }

    /**
     * Retorna a instância de {@link ClienteDTO} pelo id informado.
     *
     * @param id
     * s@return
     */
    @PreAuthorize("hasRole('ROLE_CLIENTE_PESQUISAR')")
    @ApiOperation(value = "Retorna as informações do Cliente pelo id informado.", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiResponses({
            @ApiResponse(code = 200, message = "Success", response = ClienteDTO.class),
            @ApiResponse(code = 400, message = "Bad Request", response = MessageResponse.class),
            @ApiResponse(code = 404, message = "Not Found", response = MessageResponse.class) })
    @RequestMapping(method = RequestMethod.GET, path = "/{id:[\\d]+}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getById(@ApiParam(value = "Código do Grupo", required = true) @PathVariable final BigDecimal id) {
        Validation.max("id", id, 99999999L);
        Cliente cliente = clienteService.getById(id.longValue());
        ClienteDTO clienteDTO = clienteMapper.toDTO(cliente);

        return ResponseEntity.ok(clienteDTO);
    }

    /**
     * Retorna a buscar de {@link Cliente} por {@link FiltroTipoAmigoDTO}
     *
     * @param filtroClienteDTO
     * @return
     */
    @PreAuthorize("hasRole('ROLE_CLIENTE_PESQUISAR')")
    @ApiOperation(value = "Pesquisa de Cliente.",
            notes = "Recupera as informações de Cliente conforme dados informados no filtro de busca", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiResponses({
            @ApiResponse(code = 200, message = "Success", response = ClienteDTO.class),
            @ApiResponse(code = 400, message = "Bad Request", response = MessageResponse.class),
            @ApiResponse(code = 404, message = "Not Found", response = MessageResponse.class) })
    @GetMapping(path = "/filtro", produces = { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<?> getAllByFiltro(@ApiParam(value = "Filtro de pesquisa", required = true) @ModelAttribute final FiltroClienteDTO filtroClienteDTO) {
        List<ClienteDTO> clientesDTO = new ArrayList<>();
        List<Cliente> clientes = clienteService.getClientesByFiltro(filtroClienteDTO);
        if(clientes.size() > 0){
            for (Cliente g:
             clientes) {
                ClienteDTO clienteDTO = clienteMapper.toDTO(g);
                clientesDTO.add(clienteDTO);
            }
        }

        return ResponseEntity.ok(clientesDTO);
    }

    /**
     * Retorna uma lista de {@link ClienteDTO} cadastrados.
     *
     * @return
     */
    @PreAuthorize("isAuthenticated()")
    @ApiOperation(value = "Retorna uma lista de Clientes cadastrados.", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiResponses({
            @ApiResponse(code = 200, message = "Success", response = ClienteDTO.class),
            @ApiResponse(code = 400, message = "Bad Request", response = MessageResponse.class),
            @ApiResponse(code = 404, message = "Not Found", response = MessageResponse.class)
    })
    @GetMapping(produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<?> getClientes() {
        List<Cliente> clientes = clienteService.getTodos();
        List<ClienteDTO> clientesDTO = new ArrayList<>();
        for (Cliente cliente : clientes) {
            ClienteDTO clienteDTO = clienteMapper.toDTO(cliente);
            clientesDTO.add(clienteDTO);
        }
        return ResponseEntity.ok(clientesDTO);
    }

    /**
     * Ativa o {@link Grupo} pelo 'id' informado.
     *
     * @param id
     * @return
     */
    @PreAuthorize("hasRole('ROLE_CLIENTE_REMOVER')")
    @ApiOperation(value = "Remove um Cliente pelo id informado.", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiResponses({
            @ApiResponse(code = 200, message = "Success", response = ClienteDTO.class),
            @ApiResponse(code = 400, message = "Bad Request", response = MessageResponse.class),
            @ApiResponse(code = 404, message = "Not Found", response = MessageResponse.class)
    })
    @DeleteMapping(path = "/{id:[\\d]+}", produces = { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<?> remover(@ApiParam(value = "Id do Cliente", required = true) @PathVariable final BigDecimal id) {
        Validation.max("id", id, 1000000L);
        Cliente cliente = clienteService.remover(id.longValue());
        return ResponseEntity.ok(cliente);
    }

}
