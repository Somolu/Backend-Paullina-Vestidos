package br.ueg.modelo.application.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@ApiModel(value = "Entidade de transferência de Cliente")
public @Data
class ClienteDTO implements Serializable {

    @ApiModelProperty(value = "id do Cliente")
    private Long id;

    @ApiModelProperty(value = "Nome do Cliente")
    private String nome;

    @ApiModelProperty(value = "Telefone do Cliente")
    private String telefone;

}
