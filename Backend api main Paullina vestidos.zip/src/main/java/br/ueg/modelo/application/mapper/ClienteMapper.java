package br.ueg.modelo.application.mapper;


import br.ueg.modelo.application.dto.ClienteDTO;
import br.ueg.modelo.application.model.Cliente;
import br.ueg.modelo.application.model.Modulo;
import org.mapstruct.Mapper;

/**
 * Classe adapter referente a entidade {@link Modulo}.
 *
 * @author UEG
 */
@Mapper(componentModel = "spring")
public interface ClienteMapper {
    /**
     * Converte a entidade {@link Cliente} em DTO {@link ClienteDTO}
     *
     * @param cliente
     * @return
     */

    public ClienteDTO toDTO(Cliente cliente);

    /**
     * Converte o DTO {@link ClienteDTO} para entidade {@link Cliente}
     *
     * @param clienteDTO
     * @return
     */
    public Cliente toEntity(ClienteDTO clienteDTO);
}
