package br.ueg.modelo.application.model;

import br.ueg.modelo.application.configuration.Constante;
import br.ueg.modelo.application.enums.StatusSimNao;
import br.ueg.modelo.application.enums.converter.StatusSimNaoConverter;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "TBL_PEDIDO", schema = Constante.DATABASE_OWNER)
@EqualsAndHashCode()
@SequenceGenerator(name = "TBL_S_PEDIDO", sequenceName = "TBL_S_PEDIDO", allocationSize = 1, schema = Constante.DATABASE_OWNER)
public @Data
class Pedido {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TBL_S_PEDIDO")
    @Column(name = "ID_PEDIDO", nullable = false)
    private Long id;

    @Column(name = "NOME_PEDIDO", length = 100, nullable = false)
    private String nome;

    @EqualsAndHashCode.Exclude
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_CLIENTE", referencedColumnName = "ID_CLIENTE", nullable = false)
    private Cliente tipo;

    @Column(name = "DATA_ATUALIZADO")
    private LocalDate dataPedido;

    @Convert(converter = StatusSimNaoConverter.class)
    @Column(name = "E_PEDIDO", length = 1, nullable = false)
    private StatusSimNao pedido;

//Classe será utilizada futuramente para inserção de todas as medidas do pedido
}
