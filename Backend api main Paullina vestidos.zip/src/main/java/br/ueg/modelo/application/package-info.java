/**
 * Pacote para arquivos especificos do projeto UEG-Portal-SSO
 */
package br.ueg.modelo.application;