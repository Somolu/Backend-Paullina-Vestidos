/*
 * GrupoRepositoryCustom.java
 * Copyright (c) UEG.
 *
 *
 *
 *
 */
package br.ueg.modelo.application.repository;


import br.ueg.modelo.application.dto.FiltroClienteDTO;
import br.ueg.modelo.application.dto.FiltroGrupoDTO;
import br.ueg.modelo.application.model.Cliente;
import br.ueg.modelo.application.model.Grupo;

import java.util.List;

/**
 * Classe de persistência referente a entidade {@link Cliente}.
 * 
 * @author UEG
 */
public interface ClienteRepositoryCustom {

	/**
	 * Retorna uma lista de {@link Cliente} conforme o filtro de pesquisa informado.
	 * 
	 * @param filtroClienteDTO
	 * @return
	 */
	public List<Cliente> findAllByFiltro(FiltroClienteDTO filtroClienteDTO);
	/**
	*Retorna o total de Cliente com o mesmo nome
	 */
	public Long countByNome(String nome);


}
