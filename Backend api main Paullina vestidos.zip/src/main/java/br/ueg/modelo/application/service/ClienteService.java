package br.ueg.modelo.application.service;

import br.ueg.modelo.application.configuration.Constante;
import br.ueg.modelo.application.dto.FiltroClienteDTO;
import br.ueg.modelo.application.dto.FiltroGrupoDTO;
import br.ueg.modelo.application.dto.GrupoEstatisticasDTO;
import br.ueg.modelo.application.enums.StatusAtivoInativo;
import br.ueg.modelo.application.exception.SistemaMessageCode;
import br.ueg.modelo.application.model.Cliente;
import br.ueg.modelo.application.model.Grupo;
import br.ueg.modelo.application.model.GrupoFuncionalidade;
import br.ueg.modelo.application.model.TipoAmigo;
import br.ueg.modelo.application.repository.ClienteRepository;
import br.ueg.modelo.application.repository.GrupoFuncionalidadeRepository;
import br.ueg.modelo.application.repository.UsuarioGrupoRepository;
import br.ueg.modelo.comum.exception.BusinessException;
import br.ueg.modelo.comum.util.CollectionUtil;
import br.ueg.modelo.comum.util.Util;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.*;

@Service
@Transactional(propagation = Propagation.REQUIRED)
public class ClienteService extends GenericCrudService<Cliente, Long>{
    //public class TipoAmigoService extends GenericCrudService<TipoAmigo, Long> {
    @Autowired
    private ClienteRepository clienteRepository;

    @Autowired
    private DataSource dataSource;

    /**
     * Retorna uma lista de {@link Cliente} conforme o filtro de pesquisa informado.(video exemplo crud simples 14:21)
     *
     * @param filtroDTO
     * @return
     */
    public List<Cliente> getClientesByFiltro(final FiltroClienteDTO filtroDTO) {
        validarCamposObrigatoriosFiltro(filtroDTO);

        List<Cliente> clientes = clienteRepository.findAllByFiltro(filtroDTO); // na aula continuu Grupos #########

        if (CollectionUtil.isEmpty(clientes)) {
            throw new BusinessException(SistemaMessageCode.ERRO_NENHUM_REGISTRO_ENCONTRADO_FILTROS);
        }

        return clientes;
    }

    /**
     * Verifica se pelo menos um campo de pesquisa foi informado, e se informado o
     * nome do Grupo, verifica se tem pelo meno 4 caracteres.
     *
     * @param filtroDTO
     */
    private void validarCamposObrigatoriosFiltro(final FiltroClienteDTO filtroDTO) {
        boolean vazio = Boolean.TRUE;

        if (!Util.isEmpty(filtroDTO.getNome())) {
            vazio = Boolean.FALSE;

            if (filtroDTO.getNome().trim().length() < Integer.parseInt(Constante.TAMANHO_MINIMO_PESQUISA_NOME)) {
                throw new BusinessException(SistemaMessageCode.ERRO_TAMANHO_INSUFICIENTE_FILTRO_NOME);
            }
        }

        if (vazio) {
            throw new BusinessException(SistemaMessageCode.ERRO_FILTRO_INFORMAR_OUTRO);
        }
    }


    /**
     * Retorna uma lista de {@link Cliente} cadatrados .
     *
     * @return
     */
    public List<Cliente> getTodos() {
        List<Cliente> cliente = clienteRepository.findAll();

        if (CollectionUtil.isEmpty(cliente)) {
            throw new BusinessException(SistemaMessageCode.ERRO_NENHUM_REGISTRO_ENCONTRADO);
        }
        return cliente;
    }

    /**
     * Salva a instânica de {@link Cliente} na base de dados conforme os critérios
     * especificados na aplicação.
     *
     * @param
     * @return
     */
    public Cliente salvar(Cliente cliente) {
        validarCamposObrigatorios(cliente);
        validarDuplicidade(cliente);

        Cliente grupoSaved = clienteRepository.save(cliente);
        return grupoSaved;
    }


    @Override
    public JpaRepository<Cliente, Long> getRepository() {
        return clienteRepository;
    }

    /**
     * Verifica se os Campos Obrigatórios foram preenchidos.
     *
     * @param cliente
     */
    public void validarCamposObrigatorios(final Cliente cliente) {
        boolean vazio = Boolean.FALSE;

        if (Util.isEmpty(cliente.getNome())) {
            vazio = Boolean.TRUE;
        }

        if (vazio) {
            throw new BusinessException(SistemaMessageCode.ERRO_CAMPOS_OBRIGATORIOS);
        }
    }

    /**
     * Verifica se o Cliente a ser salvo já existe na base de dados.
     *
     * @param cliente
     */
    public void validarDuplicidade(final Cliente cliente) {
        Long count = clienteRepository.countByNome(cliente.getNome());

        if (count > BigDecimal.ZERO.longValue()) {
            throw new BusinessException(SistemaMessageCode.ERRO_TIPO_AMIGO_DUPLICADO); //Usando a mesma chamada mas trocando o conteudo
        }
    }


    protected void inicializarModelParaInclusao(Cliente cliente) {
    }

    public Cliente getById(long longValue) {
        //
        return null; // Provavelmente errado
    }
}





