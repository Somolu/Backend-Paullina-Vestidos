/**
 * Pacote para incluir artefatos que poderam ser compartilhados futuramente entre outras aplicações que compartilhem
 * o acesso ao portal
 *
 */
package br.ueg.modelo.comum;