package br.ueg.modelo.portal;

import br.ueg.modelo.application.ModeloApplication;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes= ModeloApplication.class)
public class SsoApplicationTests {

    @Test
    public void contextLoads() {
    }

}
